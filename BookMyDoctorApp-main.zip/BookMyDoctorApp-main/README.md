# BookMyDoctorApp
Full-stack-java-project with backend as Springboot and frontend as ReactJs.


Book_Doctor_Appointment -This file is for backend SpringBoot.


bookdoctorapp- This folder is for frontend Reactjs
